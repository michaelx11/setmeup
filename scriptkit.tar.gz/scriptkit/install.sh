#!/usr/bin/env bash

set -e -u -o pipefail

mkdir ~/.mxtools
cp -r toolkit ~/.mxtools/

if [ -e ~/.zshrc ]; then
  printf "\nsource $HOME/.mxtools/toolkit/scripts/encryption_tools" >> ~/.zshrc
fi

if [ -e ~/.bashrc ]; then
  printf "\nsource $HOME/.mxtools/toolkit/scripts/encryption_tools" >> ~/.bashrc
fi
